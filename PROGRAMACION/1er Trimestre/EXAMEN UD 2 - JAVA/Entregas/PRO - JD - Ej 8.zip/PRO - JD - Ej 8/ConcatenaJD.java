public class ConcatenaJD {
    
    public static void main (String[] args) {

        char v1= 'J' ;
        char v2= 'a' ;
        char v3= 'i' ;
        char v4= 'm' ;
        char v5= 'e' ;

        String nombre = ""+v1+v2+v3+v4+v5;

        System.out.println(nombre);

    }


}
